# video-chat-one-to-one-node-js
simple one to one video chat app using socket.io, peer js, node js, webRTC

![one to one video chat screenshots](https://user-images.githubusercontent.com/24524924/110233509-67294f00-7f4a-11eb-9dc8-0c4e1424b860.png)
